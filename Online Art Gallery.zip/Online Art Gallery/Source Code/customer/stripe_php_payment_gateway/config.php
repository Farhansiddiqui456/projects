<?php
require('stripe-php-master/init.php');

$publishableKey="pk_test_51Mk6WTSJEZFr2Dgb3t2QUAfuREFmHrBs29KNHorRqzwbfGeciwIv1jg8ACofMgrXcBt9t1Ql5FHN1MNxxJPTUuYO007XwfjTbJ";

$secretKey="sk_test_51Mk6WTSJEZFr2DgbDEJ7msx0RtztwbAauosrXpjUEPdtEI3NNXe2H37JReWu1DbNmrxhETCT178Apjwid9iFcvl500LMEUuZAd";

\Stripe\Stripe::setApiKey($secretKey);
?>